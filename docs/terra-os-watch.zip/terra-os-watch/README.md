# TERRA OS — 户外智能手表 UI 交互演示

## 本地运行

确保已安装 Node.js (>= 20)：

```bash
# 使用 pnpm（推荐）
pnpm install
pnpm dev

# 或使用 npm
npm install
npm run dev
```

启动后在浏览器访问终端提示的本地地址（默认 `http://localhost:5173`）即可体验完整交互。

## 直接预览已构建产物

压缩包内已附带编译好的 `dist/` 静态目录，也可直接通过任意静态服务器打开：

```bash
npx serve dist
```
